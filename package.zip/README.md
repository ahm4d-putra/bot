#Script ANIME-AI
*Base By Kyami Silence*
*Pengembang Script LIGHTSECRET*
*Baileys By Daf04*

#Script ini gratis Dari LIGHTSECRET
#Dilarang Menjual Belikan

#Sumber
#https://whatsapp.com/channel/0029VbADDW2ISTkREJ5m4833
